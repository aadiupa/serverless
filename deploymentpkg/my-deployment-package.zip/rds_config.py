#config file containing credentials for RDS MySQL instance
db_username = "admin"
db_password = "12345678"
db_name = "serverless"
